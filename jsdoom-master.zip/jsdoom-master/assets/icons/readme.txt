All icons are either original art or taken from the Tango icon library.

The Tango icon library is in the public domain.

http://tango.freedesktop.org/Tango_Icon_Library
