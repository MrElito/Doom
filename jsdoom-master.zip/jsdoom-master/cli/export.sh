#!/bin/bash

# Export a lump from a WAD to a file.
# Run using the "--help" option for more details.
node dist/src/cli/export.js $@
